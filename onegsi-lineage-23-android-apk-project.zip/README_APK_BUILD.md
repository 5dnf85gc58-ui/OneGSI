# OneGSI Companion APK Project

This archive is a complete Kotlin + Jetpack Compose Android Studio / Gradle project combining **fahadalijaved/OneOS** multi-slot + hardware panic return and **WeWaffles/OneLineage** `pivot_root` GSI containerization, adapted to load **any downloaded GSI** directly on your phone.

## Option A: Build APK Automatically on GitHub (No Android Studio needed)
1. Create a new GitHub repository and upload the contents of this zip.
2. Open the **Actions** tab on GitHub and run **Build OneGSI APK** (or push to `main`).
3. Download the compiled **OneGSI-debug-apk** artifact and install it on your rooted Samsung device.

## Option B: Build Locally with Android Studio / CLI
```bash
gradle assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

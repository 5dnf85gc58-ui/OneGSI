package com.onegsi.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

data class CommandResult(
    val exitCode: Int,
    val output: String
)

object RootRunner {
    const val DEFAULT_STAGING_BASE = "/data/local/tmp/onegsi"

    suspend fun checkRoot(): Boolean = withContext(Dispatchers.IO) {
        try {
            val proc = ProcessBuilder("su", "-c", "id -u").start()
            val out = proc.inputStream.bufferedReader().readText().trim()
            proc.waitFor() == 0 && out == "0"
        } catch (_: Exception) {
            false
        }
    }

    suspend fun hasActiveLockscreen(): Boolean = withContext(Dispatchers.IO) {
        val res = execRoot("[ -n \"$(ls -A /data/system_de/0/spblob 2>/dev/null)\" ] && echo LOCKED || echo CLEAR")
        res.output.contains("LOCKED")
    }

    suspend fun listSlots(): List<String> = withContext(Dispatchers.IO) {
        val res = execRoot("ls -1 '$DEFAULT_STAGING_BASE/slots' 2>/dev/null || true")
        res.output.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    suspend fun installScriptsToSlot(
        context: Context,
        slotName: String,
        gsiFileName: String,
        compression: String,
        filesystem: String,
        mountMode: String,
        apexStrategy: String,
        enablePanicKey: Boolean,
        isolateAudio: Boolean,
        lockscreenGuard: Boolean
    ): CommandResult = withContext(Dispatchers.IO) {
        val slotDir = "$DEFAULT_STAGING_BASE/slots/$slotName"
        val scriptsDir = "$slotDir/scripts"
        execRoot("mkdir -p '$scriptsDir' '$slotDir/rootfs' '$slotDir/data'")

        val assetFiles = context.assets.list("scripts") ?: emptyArray()
        for (name in assetFiles) {
            val content = context.assets.open("scripts/$name").bufferedReader().readText()
            val patched = if (name == "onegsi.conf") {
                buildDynamicConf(
                    slotName = slotName,
                    gsiFileName = gsiFileName,
                    compression = compression,
                    filesystem = filesystem,
                    mountMode = mountMode,
                    apexStrategy = apexStrategy,
                    enablePanicKey = enablePanicKey,
                    isolateAudio = isolateAudio,
                    lockscreenGuard = lockscreenGuard
                )
            } else {
                content
            }
            val tmpFile = java.io.File(context.cacheDir, name)
            tmpFile.writeText(patched.replace("\r\n", "\n"))
            execRoot("cp '${tmpFile.absolutePath}' '$scriptsDir/$name'")
        }
        execRoot("chmod 0755 '$scriptsDir'/*.sh '$scriptsDir/zygote_exec'")
    }

    suspend fun streamUriToSlot(
        context: Context,
        uri: Uri,
        slotName: String,
        fileName: String,
        onProgress: (Long) -> Unit
    ): CommandResult = withContext(Dispatchers.IO) {
        val slotDir = "$DEFAULT_STAGING_BASE/slots/$slotName"
        val destPath = "$slotDir/$fileName"
        execRoot("mkdir -p '$slotDir'")

        try {
            val proc = ProcessBuilder("su", "-c", "cat > '$destPath'").start()
            val buffer = ByteArray(1024 * 1024)
            var total = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                proc.outputStream.use { out ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        total += read
                        onProgress(total)
                    }
                    out.flush()
                }
            }
            val code = proc.waitFor()
            val err = proc.errorStream.bufferedReader().readText()
            CommandResult(code, if (code == 0) "Copied $total bytes to $destPath" else err)
        } catch (e: Exception) {
            CommandResult(1, e.message ?: "Stream error")
        }
    }

    suspend fun execRoot(cmd: String): CommandResult = withContext(Dispatchers.IO) {
        try {
            val proc = ProcessBuilder("su", "-c", cmd)
                .redirectErrorStream(true)
                .start()
            val sb = StringBuilder()
            BufferedReader(InputStreamReader(proc.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line).append('\n')
                }
            }
            val code = proc.waitFor()
            CommandResult(code, sb.toString().trim())
        } catch (e: Exception) {
            CommandResult(1, e.message ?: "Root execution failed")
        }
    }

    private fun buildDynamicConf(
        slotName: String,
        gsiFileName: String,
        compression: String,
        filesystem: String,
        mountMode: String,
        apexStrategy: String,
        enablePanicKey: Boolean,
        isolateAudio: Boolean,
        lockscreenGuard: Boolean
    ): String {
        val slotDir = "$DEFAULT_STAGING_BASE/slots/$slotName"
        return """
            #!/system/bin/sh
            SLOT_NAME="$slotName"
            STAGING_BASE="$DEFAULT_STAGING_BASE"
            SLOT_DIR="$slotDir"
            GSI_SOURCE_FILE="$slotDir/$gsiFileName"
            GSI_RAW_IMAGE="$slotDir/system.raw.img"
            ROOTFS_DIR="$slotDir/rootfs"
            GUEST_DATA_DIR="$slotDir/data"
            OVERLAY_UPPER="$slotDir/upper"
            OVERLAY_WORK="$slotDir/work"
            LOG_FILE="$slotDir/onegsi.log"
            GSI_FLAVOR="Custom GSI"
            GSI_ANDROID_VER="16"
            GSI_SDK="36"
            GSI_VNDK="36 (VNDKless)"
            GSI_ARCH="arm64-v8a"
            GSI_COMPRESSION="$compression"
            GSI_FILESYSTEM="$filesystem"
            GSI_SAR="1"
            HOST_ONEUI="One UI 8.0 (Android 16)"
            HOST_SDK="36"
            ROOT_MANAGER="KernelSU"
            MOUNT_MODE="$mountMode"
            APEX_STRATEGY="$apexStrategy"
            SELINUX_MODE="permissive-pivot"
            ENABLE_PANIC_KEY="${if (enablePanicKey) "1" else "0"}"
            PANIC_HOLD_SECS="3"
            ISOLATE_AUDIOSERVER="${if (isolateAudio) "1" else "0"}"
            LOCKSCREEN_GUARD="${if (lockscreenGuard) "1" else "0"}"
            PHH_PROPS_OVERRIDE="1"
            ENABLE_ADB_LOGCAT="1"
        """.trimIndent() + "\n"
    }
}

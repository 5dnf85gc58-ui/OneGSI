package com.onegsi.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF8FAFC)
                ) {
                    OneGsiScreen()
                }
            }
        }
    }
}

@Composable
fun OneGsiScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var hasRoot by remember { mutableStateOf<Boolean?>(null) }
    var lockActive by remember { mutableStateOf(false) }
    var slots by remember { mutableStateOf<List<String>>(emptyList()) }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var inspected by remember { mutableStateOf<InspectedGsi?>(null) }
    var slotName by remember { mutableStateOf("lineage-23") }
    var mountMode by remember { mutableStateOf("unpacked-rootfs") }
    var apexStrategy by remember { mutableStateOf("hybrid-vndk") }
    var enablePanicKey by remember { mutableStateOf(true) }
    var isolateAudio by remember { mutableStateOf(true) }
    var lockscreenGuard by remember { mutableStateOf(true) }

    var isBusy by remember { mutableStateOf(false) }
    var logOutput by remember { mutableStateOf("Ready. Pick any downloaded .img / .img.xz / .img.gz / .zip GSI file.") }

    LaunchedEffect(Unit) {
        hasRoot = RootRunner.checkRoot()
        if (hasRoot == true) {
            lockActive = RootRunner.hasActiveLockscreen()
            slots = RootRunner.listSlots()
        }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            inspected = GsiInspector.inspectUri(context, uri)
            val base = inspected?.fileName?.substringBefore(".")
                ?.lowercase()
                ?.replace(Regex("[^a-z0-9._-]"), "-")
                ?.take(24)
            if (!base.isNullOrBlank()) {
                slotName = base
            }
            logOutput = "Inspected: ${inspected?.fileName} (${inspected?.compression} / ${inspected?.filesystem})\nMagic: ${inspected?.magicHex}"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "OneGSI",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = when (hasRoot) {
                    true -> "Root granted · ${if (lockActive) "Warning: Active One UI PIN/Biometric detected" else "Lockscreen clear"}"
                    false -> "Root denied — grant su in KernelSU/Magisk"
                    null -> "Checking root environment..."
                },
                fontSize = 13.sp,
                color = if (hasRoot == false || lockActive) Color(0xFFB91C1C) else Color(0xFF475569)
            )
        }

        HorizontalDivider(color = Color(0xFFE2E8F0))

        // 1. Pick Any GSI
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("01. Select Downloaded GSI", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(
                text = inspected?.let {
                    "${it.fileName}\nFormat: ${it.compression.uppercase()} · FS: ${it.filesystem.uppercase()} · ${it.sizeBytes / (1024 * 1024)} MB"
                } ?: "No GSI selected yet. Supports raw .img, sparse, .img.xz, .img.gz, or .zip.",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFF334155)
            )
            Button(
                onClick = { picker.launch(arrayOf("*/*")) },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
            ) {
                Text("Browse Downloaded GSI")
            }
        }

        // 2. Slot & Bridge Configuration
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("02. Slot & Container Bridge", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)

            OutlinedTextField(
                value = slotName,
                onValueChange = { slotName = it },
                label = { Text("Slot Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Mount Mode", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF475569))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("unpacked-rootfs", "overlayfs-writable", "loop-ext4").forEach { mode ->
                    FilterChip(
                        selected = mountMode == mode,
                        onClick = { mountMode = mode },
                        label = { Text(mode.substringBefore("-"), fontSize = 12.sp) }
                    )
                }
            }

            Text("APEX Strategy", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF475569))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("hybrid-vndk", "host-bind", "guest-isolated").forEach { strat ->
                    FilterChip(
                        selected = apexStrategy == strat,
                        onClick = { apexStrategy = strat },
                        label = { Text(strat.substringBefore("-"), fontSize = 12.sp) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Panic Return (Vol+ & Vol- 3s)", fontSize = 13.sp)
                Switch(checked = enablePanicKey, onCheckedChange = { enablePanicKey = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Isolate audioserver", fontSize = 13.sp)
                Switch(checked = isolateAudio, onCheckedChange = { isolateAudio = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Lockscreen Pre-flight Guard", fontSize = 13.sp)
                Switch(checked = lockscreenGuard, onCheckedChange = { lockscreenGuard = it })
            }
        }

        // 3. Actions
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("03. Stage & Hot-Switch", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)

            if (slots.isNotEmpty()) {
                Text(
                    text = "Existing slots: ${slots.joinToString(", ")}",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF475569)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val uri = selectedUri
                        val info = inspected
                        if (uri == null || info == null) {
                            logOutput = "Select a GSI file first."
                            return@Button
                        }
                        isBusy = true
                        scope.launch {
                            logOutput = "Copying ${info.fileName} into slot '$slotName'..."
                            val copyRes = RootRunner.streamUriToSlot(context, uri, slotName, info.fileName) { bytes ->
                                logOutput = "Copied ${bytes / (1024 * 1024)} MB..."
                            }
                            if (copyRes.exitCode != 0) {
                                logOutput = "Copy failed: ${copyRes.output}"
                                isBusy = false
                                return@launch
                            }
                            logOutput = "Installing scripts and running master_prepare.sh..."
                            RootRunner.installScriptsToSlot(
                                context = context,
                                slotName = slotName,
                                gsiFileName = info.fileName,
                                compression = info.compression,
                                filesystem = info.filesystem,
                                mountMode = mountMode,
                                apexStrategy = apexStrategy,
                                enablePanicKey = enablePanicKey,
                                isolateAudio = isolateAudio,
                                lockscreenGuard = lockscreenGuard
                            )
                            val prep = RootRunner.execRoot("sh '${RootRunner.DEFAULT_STAGING_BASE}/slots/$slotName/scripts/master_prepare.sh'")
                            logOutput = prep.output
                            slots = RootRunner.listSlots()
                            isBusy = false
                        }
                    },
                    enabled = !isBusy && hasRoot == true,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Stage GSI")
                }

                Button(
                    onClick = {
                        isBusy = true
                        scope.launch {
                            val res = RootRunner.execRoot("sh '${RootRunner.DEFAULT_STAGING_BASE}/slots/$slotName/scripts/switch_to_guest.sh'")
                            logOutput = res.output
                            isBusy = false
                        }
                    },
                    enabled = !isBusy && hasRoot == true,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Boot Guest")
                }
            }

            OutlinedButton(
                onClick = {
                    isBusy = true
                    scope.launch {
                        val res = RootRunner.execRoot("sh '${RootRunner.DEFAULT_STAGING_BASE}/slots/$slotName/scripts/return_to_oneui.sh'")
                        logOutput = res.output
                        isBusy = false
                    }
                },
                enabled = !isBusy && hasRoot == true,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Return to One UI")
            }
        }

        // Log Console
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Text(
                text = logOutput,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color(0xFFE2E8F0)
            )
        }
    }
}

#!/system/bin/sh
# master_inner.sh — Namespace Isolation, Bind Mounts & pivot_root
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/onegsi.conf"

echo "[inner] Preparing bind mounts inside $ROOTFS_DIR..."

# Essential kernel & binder virtual filesystems
mount --rbind /dev "$ROOTFS_DIR/dev"
mount --make-rslave "$ROOTFS_DIR/dev"
mount -t proc proc "$ROOTFS_DIR/proc"
mount -t sysfs sysfs "$ROOTFS_DIR/sys"

# Hardware HAL partitions from host Samsung One UI
for part in vendor odm; do
  if [ -d "/$part" ] && [ -d "$ROOTFS_DIR/$part" ]; then
    mount --rbind "/$part" "$ROOTFS_DIR/$part"
    mount --make-rslave "$ROOTFS_DIR/$part"
  fi
done

# Isolated guest /data bind
mount --bind "$GUEST_DATA_DIR" "$ROOTFS_DIR/data"

# APEX & LinkerConfig Bridge (hybrid-vndk)
# Strategy: Hybrid VNDK Bridge (cross-SDK GSI compatibility)
# Keep guest Runtime/ART/MediaProvider APEX intact; bind only host vendor/HAL APEXs
mkdir -p "$ROOTFS_DIR/apex"
mount -t tmpfs tmpfs "$ROOTFS_DIR/apex"
for host_apex in /apex/com.android.vndk.* /apex/com.android.hardware.* /apex/com.samsung.*; do
  [ -d "$host_apex" ] || continue
  base="$(basename "$host_apex")"
  mkdir -p "$ROOTFS_DIR/apex/$base"
  mount --bind "$host_apex" "$ROOTFS_DIR/apex/$base"
done

# Copy runtime scripts into container accessible path
mkdir -p "$ROOTFS_DIR/sbin_onegsi"
cp "$SCRIPT_DIR/zygote_exec" "$ROOTFS_DIR/sbin_onegsi/zygote_exec"
cp "$SCRIPT_DIR/onegsi.conf" "$ROOTFS_DIR/sbin_onegsi/onegsi.conf"
chmod 0755 "$ROOTFS_DIR/sbin_onegsi/zygote_exec"

echo "[inner] Executing pivot_root into $GSI_FLAVOR ($SLOT_NAME)..."
cd "$ROOTFS_DIR"
pivot_root . old_root

# Generate linkerconfig inside new rootfs if binary exists
if [ -x /system/bin/linkerconfig ]; then
  /system/bin/linkerconfig --target /linkerconfig 2>/dev/null || true
fi

exec /sbin_onegsi/zygote_exec

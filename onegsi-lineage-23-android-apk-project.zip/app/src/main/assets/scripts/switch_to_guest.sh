#!/system/bin/sh
# switch_to_guest.sh — Hot-switch from Host One UI to Guest GSI
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/onegsi.conf"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: Root required." >&2
  exit 1
fi

exec > >(tee -a "$LOG_FILE") 2>&1
echo "=== Switching to Guest GSI: $GSI_FLAVOR ($SLOT_NAME) ==="

# Pre-flight Lockscreen & Gatekeeper Guard (OneOS + OneLineage safety check)
if [ -f /data/system/locksettings.db ] && [ -s /data/system/locksettings.db ]; then
  # Check if synthetic_password directory has active keys
  if [ -n "$(ls -A /data/system_de/0/spblob 2>/dev/null || true)" ]; then
    echo "WARNING: Active One UI PIN/Pattern/Biometric detected in /data/system_de/0/spblob!" >&2
    echo "Disable screen lock in One UI Settings before switching, or removespblob guard." >&2
    exit 2
  fi
fi

# Verify rootfs is mounted/staged
if [ ! -d "$ROOTFS_DIR/system" ]; then
  echo "RootFS not staged yet. Running master_prepare.sh first..."
  sh "$SCRIPT_DIR/master_prepare.sh"
fi

# SELinux transition
PREV_ENFORCE="$(getenforce 2>/dev/null || echo Enforcing)"
echo "$PREV_ENFORCE" > "$SLOT_DIR/.host_selinux"
setenforce 0

# Start OneOS-style Hardware Panic Key Daemon (Vol+ + Vol- held 3s)
echo "  -> Starting panic_return.sh (Hold Vol+ & Vol- for 3s to abort)..."
nohup sh "$SCRIPT_DIR/panic_return.sh" "$SCRIPT_DIR" >/dev/null 2>&1 &
echo $! > "$SLOT_DIR/panic.pid"

# Suppress Host One UI graphical & zygote stack
echo "  -> Stopping host zygote and surfaceflinger..."
stop zygote 2>/dev/null || true
stop zygote_secondary 2>/dev/null || true
stop surfaceflinger 2>/dev/null || true
stop audioserver 2>/dev/null || true
stop mediaserver 2>/dev/null || true

touch "$SLOT_DIR/.guest_active"

# Enter isolated mount namespace and pivot_root
unshare -m sh "$SCRIPT_DIR/master_inner.sh"

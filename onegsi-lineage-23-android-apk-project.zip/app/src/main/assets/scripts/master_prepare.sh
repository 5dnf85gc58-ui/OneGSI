#!/system/bin/sh
# master_prepare.sh — Universal GSI Stager (OneLineage + OneOS Remix)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/onegsi.conf"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: Run as root (su -c sh $0)" >&2
  exit 1
fi

mkdir -p "$SLOT_DIR" "$GUEST_DATA_DIR" "$ROOTFS_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "=== OneGSI Prepare: slot=$SLOT_NAME flavor=$GSI_FLAVOR (API $GSI_SDK) ==="
[ -f "$GSI_SOURCE_FILE" ] || {
  echo "ERROR: GSI file not found at $GSI_SOURCE_FILE" >&2
  exit 1
}

WORK_IMG="$SLOT_DIR/work.img"
echo "[1/5] Decompressing XZ archive..."
if command -v xz >/dev/null 2>&1; then
  xz -dc "$GSI_SOURCE_FILE" > "$WORK_IMG"
elif command -v busybox >/dev/null 2>&1; then
  busybox unxz -c "$GSI_SOURCE_FILE" > "$WORK_IMG"
else
  echo "ERROR: xz or busybox unxz binary not found in PATH." >&2
  exit 1
fi

echo "[2/5] Checking Android sparse magic (0x3AFF26ED)..."
SPARSE_SRC="$WORK_IMG"
[ -f "$WORK_IMG.sparse" ] && SPARSE_SRC="$WORK_IMG.sparse"
MAGIC_HEX="$(dd if="$SPARSE_SRC" bs=4 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')"
if [ "$MAGIC_HEX" = "3aff26ed" ]; then
  echo "  -> Sparse header detected. Converting to raw ext4/erofs image..."
  if command -v simg2img >/dev/null 2>&1; then
    simg2img "$SPARSE_SRC" "$GSI_RAW_IMAGE"
  else
    echo "ERROR: simg2img required for sparse GSI. Install android-tools or convert on PC first." >&2
    exit 1
  fi
  rm -f "$WORK_IMG.sparse"
else
  [ "$SPARSE_SRC" != "$GSI_RAW_IMAGE" ] && mv "$SPARSE_SRC" "$GSI_RAW_IMAGE" 2>/dev/null || cp "$SPARSE_SRC" "$GSI_RAW_IMAGE"
fi

echo "[3/5] Unpacking GSI image into portable RootFS directory (EROFS/ext4 universal mode)..."
rm -rf "$ROOTFS_DIR"
mkdir -p "$ROOTFS_DIR" "$SLOT_DIR/mnt_probe"
if command -v extract.erofs >/dev/null 2>&1 && [ "$GSI_FILESYSTEM" = "erofs" ]; then
  extract.erofs -i "$GSI_RAW_IMAGE" -o "$ROOTFS_DIR" -x
elif command -v 7z >/dev/null 2>&1; then
  7z x "$GSI_RAW_IMAGE" -o"$ROOTFS_DIR" -y
else
  mount -o ro,loop "$GSI_RAW_IMAGE" "$SLOT_DIR/mnt_probe" || {
    echo "ERROR: Kernel cannot mount $GSI_FILESYSTEM directly and 7z/extract.erofs is unavailable." >&2
    exit 1
  }
  cp -a "$SLOT_DIR/mnt_probe/." "$ROOTFS_DIR/"
  umount "$SLOT_DIR/mnt_probe"
fi
rmdir "$SLOT_DIR/mnt_probe" 2>/dev/null || true

echo "[4/5] Normalizing System-as-Root (SAR) layout & Treble properties..."
if [ -d "$ROOTFS_DIR/system/bin" ] && [ ! -d "$ROOTFS_DIR/system/system/bin" ]; then
  echo "  -> Detected classic /system layout; creating SAR compatibility symlinks..."
  ln -sfn /system/bin "$ROOTFS_DIR/bin" 2>/dev/null || true
elif [ -d "$ROOTFS_DIR/system/system/bin" ]; then
  echo "  -> Detected SAR rootfs layout."
fi

# Ensure container mountpoints exist inside rootfs
for mnt in dev proc sys data vendor odm product apex linkerconfig mnt storage old_root; do
  mkdir -p "$ROOTFS_DIR/$mnt"
done

# Isolated guest /data skeleton (OneLineage SELinux context alignment)
for d in local system system_de system_ce user user_de data app misc property dalvik-cache; do
  mkdir -p "$GUEST_DATA_DIR/$d"
done
chmod 0771 "$GUEST_DATA_DIR"
chcon -R u:object_r:system_data_file:s0 "$GUEST_DATA_DIR" 2>/dev/null || true
chown -R 1000:1000 "$GUEST_DATA_DIR/system" "$GUEST_DATA_DIR/system_de" "$GUEST_DATA_DIR/system_ce" 2>/dev/null || true

echo "  -> Writing universal Phh-Treble / GSI runtime overrides..."
cat << 'EOF' > "$SLOT_DIR/gsi_override.prop"
ro.treble.enabled=true
persist.sys.phh.disable_audio_effects=1
persist.sys.phh.caf.audio_policy=0
persist.sys.phh.backlight.scale=1
ro.adb.secure=0
EOF

echo "[5/5] Staging complete for slot '$SLOT_NAME'."
echo "Next: Run 'su -c sh $SCRIPT_DIR/switch_to_guest.sh' to pivot into $GSI_FLAVOR."

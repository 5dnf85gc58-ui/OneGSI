#!/system/bin/sh
# panic_return.sh — OneOS Hardware Key Emergency Return (Vol Up + Vol Down)
BUNDLE_DIR="${1:-$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)}"
. "$BUNDLE_DIR/onegsi.conf"

HOLD_REQUIRED="${PANIC_HOLD_SECS:-3}"
VOL_UP=0
VOL_DOWN=0
HOLD_START=0

getevent -ql 2>/dev/null | while read -r dev type code val; do
  case "$code" in
    *KEY_VOLUMEUP*)
      [ "$val" = "DOWN" ] && VOL_UP=1 || VOL_UP=0
      ;;
    *KEY_VOLUMEDOWN*)
      [ "$val" = "DOWN" ] && VOL_DOWN=1 || VOL_DOWN=0
      ;;
  esac

  if [ "$VOL_UP" -eq 1 ] && [ "$VOL_DOWN" -eq 1 ]; then
    NOW="$(date +%s)"
    if [ "$HOLD_START" -eq 0 ]; then
      HOLD_START="$NOW"
    elif [ $((NOW - HOLD_START)) -ge "$HOLD_REQUIRED" ]; then
      echo "PANIC COMBO DETECTED (Vol+ & Vol- held 3s). Returning to One UI..." >> "$LOG_FILE"
      sh "$BUNDLE_DIR/return_to_oneui.sh"
      exit 0
    fi
  else
    HOLD_START=0
  fi
done

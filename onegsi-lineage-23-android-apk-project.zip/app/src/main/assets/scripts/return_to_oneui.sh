#!/system/bin/sh
# return_to_oneui.sh — Tear down Guest GSI Container and Restore One UI
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/onegsi.conf"

echo "=== Returning from $SLOT_NAME to Host One UI ==="

# 1. Stop panic daemon if still running
if [ -f "$SLOT_DIR/panic.pid" ]; then
  kill "$(cat "$SLOT_DIR/panic.pid")" 2>/dev/null || true
  rm -f "$SLOT_DIR/panic.pid"
fi

# 2. Terminate guest zygote / system_server processes referencing ROOTFS_DIR
for pid in /proc/[0-9]*; do
  p="${pid#/proc/}"
  if readlink "$pid/root" 2>/dev/null | grep -q "$SLOT_NAME"; then
    kill -9 "$p" 2>/dev/null || true
  fi
done

# 3. Unmount container bind mounts in reverse order
for sub in apex linkerconfig data odm vendor sys proc dev; do
  umount -l "$ROOTFS_DIR/$sub" 2>/dev/null || true
done

# unpacked-rootfs directory remains intact on storage.

# 4. Restore SELinux enforcing if saved
if [ -f "$SLOT_DIR/.host_selinux" ]; then
  HOST_SE="$(cat "$SLOT_DIR/.host_selinux")"
  [ "$HOST_SE" = "Enforcing" ] && setenforce 1 || true
  rm -f "$SLOT_DIR/.host_selinux"
fi

rm -f "$SLOT_DIR/.guest_active"

# 5. Restart Host One UI services
echo "  -> Restarting host surfaceflinger, audioserver, and zygote..."
start surfaceflinger 2>/dev/null || true
start audioserver 2>/dev/null || true
start mediaserver 2>/dev/null || true
start zygote 2>/dev/null || true
start zygote_secondary 2>/dev/null || true

echo "=== Host One UI Restored ==="

# Keep OneGSI classes
-keep class com.onegsi.app.** { *; }

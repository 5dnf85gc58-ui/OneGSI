package com.oneos.remixer

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class CommandResult(
    val exitCode: Int,
    val output: String
)

object RootRunner {
    const val STAGING_BASE = "/data/oneos"
    const val GUEST_DIR = "/data/oneos/guest"
    const val SCRIPTS_DIR = "/data/oneos/guest/scripts"

    suspend fun checkRoot(): Boolean = withContext(Dispatchers.IO) {
        try {
            val proc = ProcessBuilder("su", "-c", "id -u").start()
            val out = proc.inputStream.bufferedReader().readText().trim()
            proc.waitFor() == 0 && out == "0"
        } catch (_: Exception) {
            false
        }
    }

    suspend fun hasActiveLockscreen(): Boolean = withContext(Dispatchers.IO) {
        val checkCmd = "if [ -d /data/system_de/0/spblob ] && [ -n \"$" + "(ls -A /data/system_de/0/spblob 2>/dev/null)\" ]; then echo LOCKED; else echo CLEAR; fi"
        val res = execRoot(checkCmd)
        res.output.contains("LOCKED")
    }

    suspend fun isGuestStaged(): Boolean = withContext(Dispatchers.IO) {
        val res = execRoot("[ -d '$GUEST_DIR/rootfs/system' ] && echo STAGED || echo EMPTY")
        res.output.contains("STAGED")
    }

    suspend fun installScriptsAndReturnApk(
        context: Context,
        gsiFileName: String,
        compression: String,
        filesystem: String,
        mountMode: String,
        apexStrategy: String,
        enablePanicKey: Boolean,
        isolateAudio: Boolean,
        lockscreenGuard: Boolean
    ): CommandResult = withContext(Dispatchers.IO) {
        execRoot("mkdir -p '$SCRIPTS_DIR' '$GUEST_DIR/rootfs' '$GUEST_DIR/data/oneos_ipc'")

        val assetFiles = context.assets.list("scripts") ?: emptyArray()
        for (name in assetFiles) {
            val content = context.assets.open("scripts/$name").bufferedReader().readText()
            val patched = if (name == "oneos.conf") {
                buildDynamicConf(
                    gsiFileName = gsiFileName,
                    compression = compression,
                    filesystem = filesystem,
                    mountMode = mountMode,
                    apexStrategy = apexStrategy,
                    enablePanicKey = enablePanicKey,
                    isolateAudio = isolateAudio,
                    lockscreenGuard = lockscreenGuard
                )
            } else {
                content
            }
            val tmpFile = File(context.cacheDir, name)
            tmpFile.writeText(patched.replace("\r\n", "\n"))
            execRoot("cp '${tmpFile.absolutePath}' '$SCRIPTS_DIR/$name'")
        }

        val rootAssets = context.assets.list("") ?: emptyArray()
        if (rootAssets.contains("BackToOneUI.apk")) {
            val apkTmp = File(context.cacheDir, "BackToOneUI.apk")
            context.assets.open("BackToOneUI.apk").use { input ->
                apkTmp.outputStream().use { out -> input.copyTo(out) }
            }
            execRoot("cp '${apkTmp.absolutePath}' '$SCRIPTS_DIR/BackToOneUI.apk'")
        }

        execRoot("chmod 0755 '$SCRIPTS_DIR'/*.sh '$SCRIPTS_DIR/zygote_exec'")
    }

    suspend fun streamUriToGuestSlot(
        context: Context,
        uri: Uri,
        fileName: String,
        onProgress: (Long) -> Unit
    ): CommandResult = withContext(Dispatchers.IO) {
        val destPath = "$GUEST_DIR/$fileName"
        execRoot("mkdir -p '$GUEST_DIR'")

        try {
            val proc = ProcessBuilder("su", "-c", "cat > '$destPath'").start()
            val buffer = ByteArray(1024 * 1024)
            var total = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                proc.outputStream.use { out ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        total += read
                        onProgress(total)
                    }
                    out.flush()
                }
            }
            val code = proc.waitFor()
            val err = proc.errorStream.bufferedReader().readText()
            CommandResult(code, if (code == 0) "Copied $total bytes to $destPath" else err)
        } catch (e: Exception) {
            CommandResult(1, e.message ?: "Stream error")
        }
    }

    suspend fun execRoot(cmd: String): CommandResult = withContext(Dispatchers.IO) {
        try {
            val proc = ProcessBuilder("su", "-c", cmd)
                .redirectErrorStream(true)
                .start()
            val sb = StringBuilder()
            BufferedReader(InputStreamReader(proc.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    sb.append(line).append('\n')
                }
            }
            val code = proc.waitFor()
            CommandResult(code, sb.toString().trim())
        } catch (e: Exception) {
            CommandResult(1, e.message ?: "Root execution failed")
        }
    }

    private fun buildDynamicConf(
        gsiFileName: String,
        compression: String,
        filesystem: String,
        mountMode: String,
        apexStrategy: String,
        enablePanicKey: Boolean,
        isolateAudio: Boolean,
        lockscreenGuard: Boolean
    ): String {
        return """
            #!/system/bin/sh
            STAGING_BASE="$STAGING_BASE"
            GUEST_DIR="$GUEST_DIR"
            SCRIPTS_DIR="$SCRIPTS_DIR"
            GSI_SOURCE_FILE="$GUEST_DIR/$gsiFileName"
            GSI_RAW_IMAGE="$GUEST_DIR/system.raw.img"
            ROOTFS_DIR="$GUEST_DIR/rootfs"
            GUEST_DATA_DIR="$GUEST_DIR/data"
            OVERLAY_UPPER="$GUEST_DIR/upper"
            OVERLAY_WORK="$GUEST_DIR/work"
            IPC_DIR="$GUEST_DIR/data/oneos_ipc"
            LOG_FILE="$GUEST_DIR/oneos.log"
            SELECTED_OS="lineage-24"
            GSI_FLAVOR="LineageOS 24"
            GSI_ANDROID_VER="17"
            GSI_SDK="36"
            GSI_VNDK="36 (VNDKless)"
            GSI_ARCH="arm64-v8a"
            GSI_COMPRESSION="$compression"
            GSI_FILESYSTEM="$filesystem"
            GSI_SAR="1"
            HOST_ONEUI="One UI 8.0 (Android 16)"
            HOST_SDK="36"
            ROOT_MANAGER="KernelSU"
            MOUNT_MODE="$mountMode"
            APEX_STRATEGY="$apexStrategy"
            SELINUX_MODE="permissive-pivot"
            ENABLE_RETURN_APP="1"
            ENABLE_PANIC_KEY="${if (enablePanicKey) "1" else "0"}"
            PANIC_HOLD_SECS="3"
            ISOLATE_AUDIOSERVER="${if (isolateAudio) "1" else "0"}"
            LOCKSCREEN_GUARD="${if (lockscreenGuard) "1" else "0"}"
            PHH_PROPS_OVERRIDE="1"
            ENABLE_ADB_LOGCAT="1"
        """.trimIndent() + "\n"
    }
}

package com.oneos.remixer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                OneOsLiquidGlassScreen()
            }
        }
    }
}

@Composable
fun OneOsAppIconBadge(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF0F172A), Color(0xFF134E5E), Color(0xFF167C80))
            ),
            cornerRadius = CornerRadius(w * 0.24f, h * 0.24f)
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.20f),
            topLeft = Offset(w * 0.24f, h * 0.20f),
            size = Size(w * 0.52f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.08f, h * 0.08f)
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.16f),
            topLeft = Offset(w * 0.18f, h * 0.32f),
            size = Size(w * 0.64f, h * 0.46f),
            cornerRadius = CornerRadius(w * 0.12f, h * 0.12f)
        )
        val path = Path().apply {
            moveTo(w * 0.30f, h * 0.60f)
            cubicTo(w * 0.38f, h * 0.60f, w * 0.43f, h * 0.55f, w * 0.50f, h * 0.50f)
            cubicTo(w * 0.57f, h * 0.55f, w * 0.62f, h * 0.60f, w * 0.70f, h * 0.60f)
        }
        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
        )
        drawCircle(color = Color.White, radius = w * 0.06f, center = Offset(w * 0.30f, h * 0.60f))
        drawCircle(color = Color.White, radius = w * 0.06f, center = Offset(w * 0.70f, h * 0.60f))
        drawCircle(color = Color.White, radius = w * 0.09f, center = Offset(w * 0.50f, h * 0.46f))
    }
}

@Composable
fun LineageLogoGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF167C80), Color(0xFF0E5E62))
            ),
            cornerRadius = CornerRadius(w * 0.24f, h * 0.24f)
        )
        val path = Path().apply {
            moveTo(w * 0.24f, h * 0.60f)
            cubicTo(w * 0.34f, h * 0.60f, w * 0.40f, h * 0.54f, w * 0.50f, h * 0.46f)
            cubicTo(w * 0.60f, h * 0.54f, w * 0.66f, h * 0.60f, w * 0.76f, h * 0.60f)
        }
        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(width = w * 0.07f, cap = StrokeCap.Round)
        )
        drawCircle(color = Color.White, radius = w * 0.085f, center = Offset(w * 0.24f, h * 0.60f))
        drawCircle(color = Color.White, radius = w * 0.085f, center = Offset(w * 0.76f, h * 0.60f))
        drawCircle(color = Color.White, radius = w * 0.125f, center = Offset(w * 0.50f, h * 0.42f))
    }
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Color.White.copy(alpha = 0.78f))
            .border(1.2.dp, Color.White.copy(alpha = 0.94f), RoundedCornerShape(26.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun LiquidSegmentedSelector(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .background(Color(0xFFE2E8F0).copy(alpha = 0.70f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { (value, label) ->
            val isSelected = selected == value
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(CircleShape)
                    .background(if (isSelected) Color.White else Color.Transparent)
                    .clickable { onSelect(value) }
                    .padding(vertical = 9.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (isSelected) Color(0xFF0F172A) else Color(0xFF475569),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun LiquidSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF0F172A))
            Text(text = subtitle, fontSize = 12.sp, color = Color(0xFF64748B))
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF34C759),
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFFCBD5E1),
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun OneOsLiquidGlassScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var hasRoot by remember { mutableStateOf<Boolean?>(null) }
    var lockActive by remember { mutableStateOf(false) }
    var isStaged by remember { mutableStateOf(false) }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var inspected by remember {
        mutableStateOf(
            InspectedGsi(
                fileName = "lineage-24-oneos-arm64-ab.img.xz",
                sizeBytes = 2540880000L,
                compression = "xz",
                filesystem = "ext4",
                magicHex = "FD 37 7A 58 5A 00 00 04 E6 D6 B4 46 02 00 21 01"
            )
        )
    }

    var mountMode by remember { mutableStateOf("unpacked-rootfs") }
    var apexStrategy by remember { mutableStateOf("hybrid-vndk") }
    var enablePanicKey by remember { mutableStateOf(true) }
    var isolateAudio by remember { mutableStateOf(true) }
    var lockscreenGuard by remember { mutableStateOf(true) }

    var isBusy by remember { mutableStateOf(false) }
    var logOutput by remember {
        mutableStateOf("Ready · Slot: ${RootRunner.GUEST_DIR}\nOS: LineageOS 24 (OneOS MysticGSI)")
    }

    LaunchedEffect(Unit) {
        hasRoot = RootRunner.checkRoot()
        if (hasRoot == true) {
            lockActive = RootRunner.hasActiveLockscreen()
            isStaged = RootRunner.isGuestStaged()
        }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            inspected = GsiInspector.inspectUri(context, uri)
            logOutput = "Loaded GSI: ${inspected.fileName}\n${inspected.compression.uppercase()} · ${inspected.filesystem.uppercase()} · ${inspected.magicHex}"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFEEF3FA), Color(0xFFE3ECF7), Color(0xFFDAE5F3))
                )
            )
    ) {
        // Subtle ambient glow behind liquid glass layers
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF167C80).copy(alpha = 0.14f), Color.Transparent),
                    center = Offset(size.width * 0.15f, size.height * 0.10f),
                    radius = size.width * 0.65f
                )
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF007AFF).copy(alpha = 0.12f), Color.Transparent),
                    center = Offset(size.width * 0.88f, size.height * 0.25f),
                    radius = size.width * 0.60f
                )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // iOS 26 Large Title + App Icon Header
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OneOsAppIconBadge(modifier = Modifier.size(54.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "OneOS",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.8).sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = when (hasRoot) {
                            true -> "Root Ready · ${if (lockActive) "Remove Screen Lock" else "Lock Clear"} · ${if (isStaged) "Staged" else "Unstaged"}"
                            false -> "Root Required (KernelSU / Magisk)"
                            null -> "Checking root..."
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (hasRoot == false || lockActive) Color(0xFFFF3B30) else Color(0xFF475569)
                    )
                }
            }

            // Section 1: OS Selector (LineageOS 24 Only)
            LiquidGlassCard {
                Text(
                    text = "OS SELECTOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.8.sp,
                    color = Color(0xFF64748B)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF167C80).copy(alpha = 0.08f))
                        .border(1.5.dp, Color(0xFF167C80).copy(alpha = 0.55f), RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    LineageLogoGlyph(modifier = Modifier.size(46.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "LineageOS 24",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "OneOS MysticGSI · Single Slot · Back to One UI app",
                            fontSize = 12.sp,
                            color = Color(0xFF475569)
                        )
                    }
                    Text(
                        text = "Active",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF167C80)
                    )
                }
            }

            // Section 2: Downloaded GSI Image
            LiquidGlassCard {
                Text(
                    text = "GUEST GSI IMAGE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.8.sp,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = inspected.fileName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF0F172A),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${inspected.compression.uppercase()} · ${inspected.filesystem.uppercase()} · ${inspected.sizeBytes / (1024 * 1024)} MB",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF475569)
                )
                Button(
                    onClick = { picker.launch(arrayOf("*/*")) },
                    enabled = !isBusy,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A)),
                    modifier = Modifier.fillMaxWidth().height(46.dp)
                ) {
                    Text("Choose Downloaded GSI (.img / .xz / .gz)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            // Section 3: iOS Grouped Container Settings
            LiquidGlassCard {
                Text(
                    text = "CONTAINER & RETURN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.8.sp,
                    color = Color(0xFF64748B)
                )

                Text("Mount Mode", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF475569))
                LiquidSegmentedSelector(
                    options = listOf(
                        "unpacked-rootfs" to "Unpacked",
                        "overlayfs-writable" to "OverlayFS",
                        "loop-ext4" to "Loop ext4"
                    ),
                    selected = mountMode,
                    onSelect = { mountMode = it }
                )

                Text("APEX Bridge", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF475569))
                LiquidSegmentedSelector(
                    options = listOf(
                        "hybrid-vndk" to "Hybrid VNDK",
                        "host-bind" to "Host Bind",
                        "guest-isolated" to "Isolated"
                    ),
                    selected = apexStrategy,
                    onSelect = { apexStrategy = it }
                )

                HorizontalDivider(thickness = 0.5.dp, color = Color(0xFFCBD5E1))

                LiquidSwitchRow(
                    title = "Hardware Panic Key",
                    subtitle = "Hold Vol+ & Vol- for 3s to return",
                    checked = enablePanicKey,
                    onCheckedChange = { enablePanicKey = it }
                )

                HorizontalDivider(thickness = 0.5.dp, color = Color(0xFFCBD5E1))

                LiquidSwitchRow(
                    title = "Isolate audioserver",
                    subtitle = "Prevents guest AudioService binder deadlock",
                    checked = isolateAudio,
                    onCheckedChange = { isolateAudio = it }
                )

                HorizontalDivider(thickness = 0.5.dp, color = Color(0xFFCBD5E1))

                LiquidSwitchRow(
                    title = "Lockscreen Guard",
                    subtitle = "Block switch if One UI PIN/Biometric is active",
                    checked = lockscreenGuard,
                    onCheckedChange = { lockscreenGuard = it }
                )
            }

            // Section 4: Actions
            LiquidGlassCard {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            isBusy = true
                            scope.launch {
                                val uri = selectedUri
                                if (uri != null) {
                                    logOutput = "Copying ${inspected.fileName} into ${RootRunner.GUEST_DIR}..."
                                    val copyRes = RootRunner.streamUriToGuestSlot(context, uri, inspected.fileName) { bytes ->
                                        logOutput = "Copied ${bytes / (1024 * 1024)} MB..."
                                    }
                                    if (copyRes.exitCode != 0) {
                                        logOutput = "Copy failed: ${copyRes.output}"
                                        isBusy = false
                                        return@launch
                                    }
                                }
                                logOutput = "Staging scripts + Back to One UI app..."
                                RootRunner.installScriptsAndReturnApk(
                                    context = context,
                                    gsiFileName = inspected.fileName,
                                    compression = inspected.compression,
                                    filesystem = inspected.filesystem,
                                    mountMode = mountMode,
                                    apexStrategy = apexStrategy,
                                    enablePanicKey = enablePanicKey,
                                    isolateAudio = isolateAudio,
                                    lockscreenGuard = lockscreenGuard
                                )
                                val prep = RootRunner.execRoot("sh '${RootRunner.SCRIPTS_DIR}/master_prepare.sh'")
                                logOutput = prep.output.ifBlank { "Staging complete (exit ${prep.exitCode})." }
                                isStaged = RootRunner.isGuestStaged()
                                isBusy = false
                            }
                        },
                        enabled = !isBusy && hasRoot == true,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF167C80)),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) {
                        Text("Stage OS", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            isBusy = true
                            scope.launch {
                                val res = RootRunner.execRoot("sh '${RootRunner.SCRIPTS_DIR}/switch_to_guest.sh'")
                                logOutput = res.output.ifBlank { "Booting LineageOS 24..." }
                                isBusy = false
                            }
                        },
                        enabled = !isBusy && hasRoot == true,
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007AFF)),
                        modifier = Modifier.weight(1f).height(50.dp)
                    ) {
                        Text("Switch OS", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Glass Terminal Log
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFF0F172A).copy(alpha = 0.92f))
                    .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = logOutput,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFE2E8F0)
                )
            }
        }
    }
}

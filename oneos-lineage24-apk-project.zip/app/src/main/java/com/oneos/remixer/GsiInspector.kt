package com.oneos.remixer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class InspectedGsi(
    val fileName: String,
    val sizeBytes: Long,
    val compression: String,
    val filesystem: String,
    val magicHex: String
)

object GsiInspector {
    fun inspectUri(context: Context, uri: Uri): InspectedGsi {
        var name = "lineage-24-oneos-arm64-ab.img.xz"
        var size = 0L

        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
            }
        }

        val header = ByteArray(8192)
        var readLen = 0
        context.contentResolver.openInputStream(uri)?.use { stream ->
            while (readLen < header.size) {
                val n = stream.read(header, readLen, header.size - readLen)
                if (n <= 0) break
                readLen += n
            }
        }

        var compression = "raw"
        var filesystem = "unknown"
        var magicOffset = 0

        if (readLen >= 6 &&
            header[0] == 0xFD.toByte() && header[1] == 0x37.toByte() &&
            header[2] == 0x7A.toByte() && header[3] == 0x58.toByte() &&
            header[4] == 0x5A.toByte() && header[5] == 0x00.toByte()
        ) {
            compression = "xz"
            filesystem = if (name.contains("erofs", ignoreCase = true)) "erofs" else "ext4"
        } else if (readLen >= 2 && header[0] == 0x1F.toByte() && header[1] == 0x8B.toByte()) {
            compression = "gzip"
            filesystem = if (name.contains("erofs", ignoreCase = true)) "erofs" else "ext4"
        } else if (readLen >= 4 &&
            header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
            header[2] == 0x03.toByte() && header[3] == 0x04.toByte()
        ) {
            compression = "zip"
            filesystem = "ext4"
        } else if (readLen >= 28) {
            val leMagic = ByteBuffer.wrap(header, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (leMagic == 0xED26FF3A.toInt()) {
                compression = "sparse"
                filesystem = "ext4"
            }
        }

        if (compression == "raw" && readLen >= 0x440) {
            val ext4Magic = ByteBuffer.wrap(header, 0x438, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF
            val erofsMagic = ByteBuffer.wrap(header, 0x400, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (ext4Magic == 0xEF53) {
                filesystem = "ext4"
                magicOffset = 0x400
            } else if (erofsMagic == 0xE0F5E1E2.toInt()) {
                filesystem = "erofs"
                magicOffset = 0x400
            }
        }

        val hex = header.slice(magicOffset until minOf(magicOffset + 16, readLen))
            .joinToString(" ") { "%02X".format(it) }

        return InspectedGsi(
            fileName = name,
            sizeBytes = size,
            compression = compression,
            filesystem = filesystem,
            magicHex = hex
        )
    }
}

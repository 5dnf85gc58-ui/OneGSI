#!/system/bin/sh
# return_to_oneui.sh — Tear down OneOS Guest Container & Restore One UI
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/oneos.conf"

echo "=== Returning to Host One UI ==="

if [ -f "$GUEST_DIR/return_daemon.pid" ]; then
  kill "$(cat "$GUEST_DIR/return_daemon.pid")" 2>/dev/null || true
  rm -f "$GUEST_DIR/return_daemon.pid"
fi

rm -f "$IPC_DIR/return_now"

for pid in /proc/[0-9]*; do
  p="${pid#/proc/}"
  if readlink "$pid/root" 2>/dev/null | grep -q "/guest/rootfs"; then
    kill -9 "$p" 2>/dev/null || true
  fi
done

for sub in apex linkerconfig data odm vendor sys proc dev; do
  umount -l "$ROOTFS_DIR/$sub" 2>/dev/null || true
done

# unpacked-rootfs preserved on storage.

if [ -f "$GUEST_DIR/.host_selinux" ]; then
  HOST_SE="$(cat "$GUEST_DIR/.host_selinux")"
  [ "$HOST_SE" = "Enforcing" ] && setenforce 1 || true
  rm -f "$GUEST_DIR/.host_selinux"
fi

rm -f "$GUEST_DIR/.guest_active"

start surfaceflinger 2>/dev/null || true
start audioserver 2>/dev/null || true
start mediaserver 2>/dev/null || true
start zygote 2>/dev/null || true
start zygote_secondary 2>/dev/null || true

echo "=== Host One UI Restored ==="

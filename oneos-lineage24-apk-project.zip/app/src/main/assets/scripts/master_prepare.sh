#!/system/bin/sh
# master_prepare.sh — OneOS Single-Slot GSI Stager (POSIX / Android mksh safe)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/oneos.conf"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: Root required (su -c sh $0)" >&2
  exit 1
fi

mkdir -p "$GUEST_DIR" "$GUEST_DATA_DIR" "$ROOTFS_DIR" "$IPC_DIR"
exec >> "$LOG_FILE" 2>&1

echo "=== OneOS Prepare: $GSI_FLAVOR (API $GSI_SDK) ==="
if [ ! -f "$GSI_SOURCE_FILE" ]; then
  echo "ERROR: GSI image not found at $GSI_SOURCE_FILE" >&2
  exit 1
fi

WORK_IMG="$GUEST_DIR/work.img"
echo "[1/5] Decompressing XZ GSI archive..."
if command -v xz >/dev/null 2>&1; then
  xz -dc "$GSI_SOURCE_FILE" > "$WORK_IMG"
elif command -v busybox >/dev/null 2>&1; then
  busybox unxz -c "$GSI_SOURCE_FILE" > "$WORK_IMG"
else
  echo "ERROR: xz or busybox unxz binary not found in PATH." >&2
  exit 1
fi

echo "[2/5] Checking Android sparse magic (0x3AFF26ED)..."
SPARSE_SRC="$WORK_IMG"
[ -f "$WORK_IMG.sparse" ] && SPARSE_SRC="$WORK_IMG.sparse"
MAGIC_HEX="$(dd if="$SPARSE_SRC" bs=4 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')"
if [ "$MAGIC_HEX" = "3aff26ed" ]; then
  echo "  -> Sparse image detected. Converting with simg2img..."
  if command -v simg2img >/dev/null 2>&1; then
    simg2img "$SPARSE_SRC" "$GSI_RAW_IMAGE"
  else
    echo "ERROR: simg2img binary required for sparse image." >&2
    exit 1
  fi
  rm -f "$WORK_IMG.sparse"
else
  if [ "$SPARSE_SRC" != "$GSI_RAW_IMAGE" ]; then
    mv "$SPARSE_SRC" "$GSI_RAW_IMAGE" 2>/dev/null || cp "$SPARSE_SRC" "$GSI_RAW_IMAGE"
  fi
fi

echo "[3/5] Unpacking GSI image into OneOS guest RootFS folder..."
rm -rf "$ROOTFS_DIR"
mkdir -p "$ROOTFS_DIR" "$GUEST_DIR/mnt_probe"
if command -v extract.erofs >/dev/null 2>&1 && [ "$GSI_FILESYSTEM" = "erofs" ]; then
  extract.erofs -i "$GSI_RAW_IMAGE" -o "$ROOTFS_DIR" -x
elif command -v 7z >/dev/null 2>&1; then
  7z x "$GSI_RAW_IMAGE" -o"$ROOTFS_DIR" -y
else
  mount -o ro,loop "$GSI_RAW_IMAGE" "$GUEST_DIR/mnt_probe" || {
    echo "ERROR: Kernel cannot loop-mount $GSI_FILESYSTEM and 7z/extract.erofs is missing." >&2
    exit 1
  }
  cp -a "$GUEST_DIR/mnt_probe/." "$ROOTFS_DIR/"
  umount "$GUEST_DIR/mnt_probe"
fi
rmdir "$GUEST_DIR/mnt_probe" 2>/dev/null || true

echo "[4/5] Normalizing System-as-Root (SAR), /data labels & Back to One UI app..."
if [ -d "$ROOTFS_DIR/system/bin" ] && [ ! -d "$ROOTFS_DIR/system/system/bin" ]; then
  ln -sfn /system/bin "$ROOTFS_DIR/bin" 2>/dev/null || true
fi

for mnt in dev proc sys data vendor odm product apex linkerconfig mnt storage old_root; do
  mkdir -p "$ROOTFS_DIR/$mnt"
done

for d in local system system_de system_ce user user_de data app misc property dalvik-cache oneos_ipc; do
  mkdir -p "$GUEST_DATA_DIR/$d"
done
chmod 0771 "$GUEST_DATA_DIR"
chmod 0777 "$IPC_DIR"
chcon -R u:object_r:system_data_file:s0 "$GUEST_DATA_DIR" 2>/dev/null || true
chcon -R u:object_r:app_data_file:s0 "$IPC_DIR" 2>/dev/null || true
chown -R 1000:1000 "$GUEST_DATA_DIR/system" "$GUEST_DATA_DIR/system_de" "$GUEST_DATA_DIR/system_ce" 2>/dev/null || true

# Install BackToOneUI.apk inside guest OS if bundled with scripts
if [ -f "$SCRIPT_DIR/BackToOneUI.apk" ]; then
  if [ -d "$ROOTFS_DIR/system/system/priv-app" ]; then
    mkdir -p "$ROOTFS_DIR/system/system/priv-app/BackToOneUI"
    cp "$SCRIPT_DIR/BackToOneUI.apk" "$ROOTFS_DIR/system/system/priv-app/BackToOneUI/BackToOneUI.apk"
    chmod 0644 "$ROOTFS_DIR/system/system/priv-app/BackToOneUI/BackToOneUI.apk"
  elif [ -d "$ROOTFS_DIR/system/priv-app" ]; then
    mkdir -p "$ROOTFS_DIR/system/priv-app/BackToOneUI"
    cp "$SCRIPT_DIR/BackToOneUI.apk" "$ROOTFS_DIR/system/priv-app/BackToOneUI/BackToOneUI.apk"
    chmod 0644 "$ROOTFS_DIR/system/priv-app/BackToOneUI/BackToOneUI.apk"
  fi
  cp "$SCRIPT_DIR/BackToOneUI.apk" "$GUEST_DATA_DIR/local/tmp/BackToOneUI.apk" 2>/dev/null || true
  echo "  -> Installed Back to One UI guest app."
fi

cat << 'EOF' > "$GUEST_DIR/gsi_override.prop"
ro.treble.enabled=true
persist.sys.phh.disable_audio_effects=1
persist.sys.phh.caf.audio_policy=0
persist.sys.phh.backlight.scale=1
ro.adb.secure=0
EOF

echo "[5/5] OneOS guest staging complete. Ready to boot $GSI_FLAVOR."

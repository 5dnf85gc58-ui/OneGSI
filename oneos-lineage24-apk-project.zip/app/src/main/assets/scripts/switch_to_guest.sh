#!/system/bin/sh
# switch_to_guest.sh — Hot-switch from Host One UI to OneOS Guest (LineageOS 24)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
. "$SCRIPT_DIR/oneos.conf"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: Root required." >&2
  exit 1
fi

exec >> "$LOG_FILE" 2>&1
echo "=== Switching to $GSI_FLAVOR ==="

if [ -f /data/system/locksettings.db ] && [ -s /data/system/locksettings.db ]; then
  if [ -n "$(ls -A /data/system_de/0/spblob 2>/dev/null || true)" ]; then
    echo "ERROR: Active One UI PIN/Pattern/Biometric detected! Remove screen lock before switching." >&2
    exit 2
  fi
fi

if [ ! -d "$ROOTFS_DIR/system" ]; then
  sh "$SCRIPT_DIR/master_prepare.sh"
fi

rm -f "$IPC_DIR/return_now"
PREV_ENFORCE="$(getenforce 2>/dev/null || echo Enforcing)"
echo "$PREV_ENFORCE" > "$GUEST_DIR/.host_selinux"
setenforce 0

# Start OneOS Return Daemon (monitors Back to One UI app IPC + Vol+ & Vol- hardware hold)
nohup sh "$SCRIPT_DIR/return_daemon.sh" "$SCRIPT_DIR" >/dev/null 2>&1 &
echo $! > "$GUEST_DIR/return_daemon.pid"

stop zygote 2>/dev/null || true
stop zygote_secondary 2>/dev/null || true
stop surfaceflinger 2>/dev/null || true
stop audioserver 2>/dev/null || true
stop mediaserver 2>/dev/null || true

touch "$GUEST_DIR/.guest_active"
unshare -m sh "$SCRIPT_DIR/master_inner.sh"

#!/system/bin/sh
# return_daemon.sh — OneOS Return Watcher (Back to One UI app + Vol+ & Vol- 3s hold)
BUNDLE_DIR="${1:-$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)}"
. "$BUNDLE_DIR/oneos.conf"

HOLD_REQUIRED="${PANIC_HOLD_SECS:-3}"

# Watcher 1: Poll Back to One UI app IPC trigger inside guest /data/oneos_ipc/return_now
(
  while [ -f "$GUEST_DIR/.guest_active" ]; do
    if [ -f "$IPC_DIR/return_now" ]; then
      echo "Back to One UI app trigger detected. Returning to One UI..." >> "$LOG_FILE"
      sh "$BUNDLE_DIR/return_to_oneui.sh"
      exit 0
    fi
    sleep 1
  done
) &

# Watcher 2: Hardware Volume Up + Volume Down combo
if [ "$ENABLE_PANIC_KEY" = "1" ]; then
  VOL_UP=0
  VOL_DOWN=0
  HOLD_START=0

  getevent -ql 2>/dev/null | while read -r dev type code val; do
    case "$code" in
      *KEY_VOLUMEUP*)
        [ "$val" = "DOWN" ] && VOL_UP=1 || VOL_UP=0
        ;;
      *KEY_VOLUMEDOWN*)
        [ "$val" = "DOWN" ] && VOL_DOWN=1 || VOL_DOWN=0
        ;;
    esac

    if [ "$VOL_UP" -eq 1 ] && [ "$VOL_DOWN" -eq 1 ]; then
      NOW="$(date +%s)"
      if [ "$HOLD_START" -eq 0 ]; then
        HOLD_START="$NOW"
      elif [ $((NOW - HOLD_START)) -ge "$HOLD_REQUIRED" ]; then
        echo "Hardware panic combo (Vol+ & Vol- 3s) detected." >> "$LOG_FILE"
        sh "$BUNDLE_DIR/return_to_oneui.sh"
        exit 0
      fi
    else
      HOLD_START=0
    fi
  done
fi

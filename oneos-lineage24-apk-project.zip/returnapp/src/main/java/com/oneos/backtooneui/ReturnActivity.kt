package com.oneos.backtooneui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReturnActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                BackToOneUiScreen()
            }
        }
    }
}

@Composable
fun BackToOneUiScreen() {
    val scope = rememberCoroutineScope()
    var statusText by remember { mutableStateOf("Tap below to cleanly exit LineageOS 24 and restore Samsung One UI.") }
    var returning by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFEEF3FA), Color(0xFFE1EAF6))
                )
            )
            .systemBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(30.dp))
                .background(Color.White.copy(alpha = 0.78f))
                .border(1.2.dp, Color.White.copy(alpha = 0.92f), RoundedCornerShape(30.dp))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ReturnAppIconGlyph(modifier = Modifier.size(72.dp))
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Back to One UI",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                color = Color(0xFF0F172A)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = statusText,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                textAlign = TextAlign.Center,
                color = Color(0xFF475569)
            )
            Spacer(modifier = Modifier.height(26.dp))
            Button(
                onClick = {
                    returning = true
                    statusText = "Signaling OneOS host daemon to unmount container and restore One UI..."
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            try {
                                val ipcDir = File("/data/oneos_ipc")
                                if (!ipcDir.exists()) ipcDir.mkdirs()
                                File(ipcDir, "return_now").writeText("1")
                            } catch (_: Exception) {
                            }
                            try {
                                ProcessBuilder(
                                    "su",
                                    "-c",
                                    "touch /data/oneos_ipc/return_now && sh /data/oneos/guest/scripts/return_to_oneui.sh"
                                ).start()
                            } catch (_: Exception) {
                            }
                        }
                    }
                },
                enabled = !returning,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF007AFF),
                    disabledContainerColor = Color(0xFF007AFF).copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text(
                    text = if (returning) "Returning to One UI..." else "Return to One UI",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun ReturnAppIconGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF007AFF), Color(0xFF1E40AF))
            ),
            cornerRadius = CornerRadius(w * 0.24f, h * 0.24f)
        )
        val arrowHead = Path().apply {
            moveTo(w * 0.39f, h * 0.39f)
            lineTo(w * 0.26f, h * 0.50f)
            lineTo(w * 0.39f, h * 0.61f)
        }
        drawPath(
            path = arrowHead,
            color = Color.White,
            style = Stroke(width = w * 0.065f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        val loopPath = Path().apply {
            moveTo(w * 0.28f, h * 0.50f)
            lineTo(w * 0.61f, h * 0.50f)
            cubicTo(w * 0.72f, h * 0.50f, w * 0.75f, h * 0.56f, w * 0.75f, h * 0.63f)
            cubicTo(w * 0.75f, h * 0.70f, w * 0.70f, h * 0.74f, w * 0.61f, h * 0.74f)
            lineTo(w * 0.48f, h * 0.74f)
        }
        drawPath(
            path = loopPath,
            color = Color.White,
            style = Stroke(width = w * 0.065f, cap = StrokeCap.Round)
        )
    }
}

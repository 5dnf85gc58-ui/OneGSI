# OneOS — LineageOS 24 Companion Project (iOS 26/27 Liquid Glass UI + Adaptive Icons)

## Features
- **iOS 26/27 Liquid Glass Compose UI**: Frosted translucent layered cards, specular rims, iOS green toggles, segmented selectors, and large title header.
- **Adaptive App Icons**: Vector squircle icons included for both **OneOS** (`:app`) and **Back to One UI** (`:returnapp`).
- **Single Guest Slot**: `/data/oneos/guest` with LineageOS 24 (OneOS MysticGSI) and local downloaded GSI support.

## Single-ZIP GitHub APK Build (No Folders Needed)
1. Upload the single `.zip` file to a GitHub repo (**Add file -> Upload files**).
2. Create `.github/workflows/build-apk.yml` and paste the workflow YAML.
3. Open **Actions** and download **OneOS-Lineage24-APKs** (`app-debug.apk` + `returnapp-debug.apk`).
